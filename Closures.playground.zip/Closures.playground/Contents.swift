

import UIKit
import PlaygroundSupport
import Foundation

func calculator1 (n1: Int, n2: Int) -> Int {
    
    return n1 + n2
    
}

calculator1(n1: 6, n2: 2)


//Closure function


func calculator (n1: Int, n2: Int, operation: (Int, Int) -> Int  ) -> Int {
    
    return operation(n1, n2)
    

}

func add (n1: Int, n2: Int) -> Int {
    return n1 + n2

}

func sub (n1: Int, n2: Int) -> Int {
    return n1 - n2

}


func multi (n1: Int, n2: Int) -> Int {
    return n1 * n2

}
func division (n1: Int, n2: Int) -> Int {
    return n1 / n2

}

calculator(n1: 6, n2: 2, operation: add)


let result = calculator (n1: 6, n2: 2) {$0 + $1}

//  { ( \parameters\ ) -> \return type\ in \statements }


//udemy 186 no
