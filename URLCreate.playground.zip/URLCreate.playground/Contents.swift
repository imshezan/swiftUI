import UIKit
import Foundation
import SwiftUI



func getCurrentImage(imageUrl: String, shopName: String?) -> URL? {
    if  imageUrl != "" && shopName != "" {
        let shop = shopName!.replacingOccurrences(of: " ", with: "%20")
        
        // https://cdn.something.com/test/Products/DOLCE/glt5bdos.jpg
        let u = URL(string: "https://cdn.something.com/test/"+"images/Products/\(shop)/small/\(imageUrl)")
        
        // print(u)
        return u
    }
    else if imageUrl != "" {
        // https://cdn.something.com/test/Category/yvoeq0sf.PNG
        let u = URL(string: "https://cdn.something.com/test/"+"images/Category/small/\(imageUrl)")
        return u
        
    }
    else{
        return nil
    }
}

//https://cdn.something.com/test/images/Products/DOLCE/glt5bdos.jpg

print(getCurrentImage(imageUrl: "category.jpg", shopName: ""))
print(getCurrentImage(imageUrl: "product.jpg", shopName: "shop"))
