import UIKit
import Foundation
import SwiftUI

var Email: String = "go@go.go"

var msg: String = ""

func isValidEmail(email:String) -> Bool {
print("validate emilId: \(email)")
let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
let result = emailTest.evaluate(with: email)
return result
}
if isValidEmail(email: Email) == true{
    msg = "this is e-mail!"
}
else {
    msg = "False"
}



var phn : String = "+8801557711220"
 
func isPhoneValid(phone:String) -> Bool {
print("validate Phone : \(phone)")
let phnRegex = "^((\\+)|(00))[0-9]{6,16}$|[0-9]{6,16}$  "

let phoneTest = NSPredicate(format:"SELF MATCHES %@", phnRegex)
let result = phoneTest.evaluate(with: phone)
return result
}

if isPhoneValid(phone: phn) == true{
    msg = "Phone Number valid"
}
else {
    msg = "False"
}
